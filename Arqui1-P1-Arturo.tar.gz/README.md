Aquí se mencionan las herramientas utilizadas durante el desarrollo de la aplicación de desencriptación RSA del curso Arquitectura de Computadores I del Instituto Tecnológico de Costa Rica.

1. Se utilizó el sistema operativo Ubuntu 20.04.
2. Se eligió el ISA x86-64 para el programa que desencripta la imagen, este facilita la interacción con el sistema operartivo para realizar llamadas al sistema con el fin de realizar la lectura y escritura de archivos.
3. Se utilizó el ensamblador NASM para crear el archivo objeto, y se utilizó ld (GNU linker) para crear el ejecutable.
4. Se programó el código en el IDE Visual Studio Code.
5. Se llevó un control de versiones del código con GitHub y GitKraken.
6. Se eligió Octave para programar el visualizador de imágenes y ejecutar el programa en ensamblador.
